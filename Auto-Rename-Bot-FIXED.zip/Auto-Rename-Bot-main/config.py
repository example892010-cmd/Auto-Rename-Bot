import os
import re
import time


def _optional_int(value, default=None):
    value = str(value or "").strip()
    if not value:
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"Invalid integer value: {value!r}") from exc


class Config:
    API_ID = os.environ.get("API_ID", "").strip()
    API_HASH = os.environ.get("API_HASH", "").strip()
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()

    DB_NAME = os.environ.get("DB_NAME", "autorename").strip() or "autorename"
    DB_URL = os.environ.get("DB_URL", "").strip()

    BOT_UPTIME = time.time()
    START_PIC = os.environ.get("START_PIC", "").strip()
    ADMIN = []
    for _admin in os.environ.get("ADMIN", "").replace(",", " ").split():
        try:
            ADMIN.append(int(_admin))
        except ValueError:
            ADMIN.append(_admin)

    FORCE_SUB = os.environ.get("FORCE_SUB", "").strip()
    LOG_CHANNEL = _optional_int(os.environ.get("LOG_CHANNEL"), None)

    _webhook = os.environ.get("WEBHOOK", "False").strip().lower()
    WEBHOOK = _webhook in {"1", "true", "yes", "on"}

    @classmethod
    def validate(cls):
        missing = []
        if not cls.API_ID:
            missing.append("API_ID")
        if not cls.API_HASH:
            missing.append("API_HASH")
        if not cls.BOT_TOKEN:
            missing.append("BOT_TOKEN")
        if not cls.DB_URL:
            missing.append("DB_URL")
        if missing:
            raise RuntimeError("Missing required environment variables: " + ", ".join(missing))


class Txt:
    START_TXT = """👋 Hello {}!

➻ Advanced Auto Rename Bot
➻ Custom Thumbnail & Caption
➻ Use /tutorial To Get Started

⚡ Powered By @ANIFLIXANIMETAMIL
👨‍💻 Developer: @TANJIROKAMADO404"""

    FILE_NAME_TXT = """<b><u>SETUP AUTO RENAME FORMAT</u></b>

Use These Keywords To Setup Custom File Name

✓ episode :- To Replace Episode Number
✓ quality :- To Replace Video Resolution

<b>➻ Example :</b> <code>/autorename @ANIFLIXANIMETAMIL - Naruto S02 EpEpisode [quality] [TAMIL]</code>

<b>➻ Your Current Auto Rename Format :</b> <code>{format_template}</code>"""

    ABOUT_TXT = """<b>🤖 My Name :</b> ANIFLIX RENAME BOT ⚡
<b>📝 Language :</b> Python 3
<b>📚 Library :</b> Pyrogram 2.0
<b>🚀 Server :</b> Railway
<b>📢 Channel :</b> @ANIFLIXANIMETAMIL
<b>🧑‍💻 Developer :</b> TANJIRO

<b>♻️ Bot Made By :</b> @TANJIROKAMADO404"""

    THUMBNAIL_TXT = """<b><u>🖼️ HOW TO SET THUMBNAIL</u></b>

⦿ Send a photo to me to save it as your thumbnail.
⦿ /viewthumb - View your thumbnail
⦿ /delthumb - Delete your thumbnail"""

    CAPTION_TXT = """<b><u>📝 HOW TO SET CAPTION</u></b>

⦿ /set_caption - Set your caption
⦿ /see_caption - View your caption
⦿ /del_caption - Delete your caption"""

    PROGRESS_BAR = """\n<b>📁 Size</b> : {1} | {2}
<b>⏳️ Done</b> : {0}%
<b>🚀 Speed</b> : {3}/s
<b>⏰️ ETA</b> : {4}"""

    DONATE_TXT = """<b>🥲 Thanks For Showing Interest In Donation! ❤️</b>

If You Like My Bots & Projects, You Can 🎁 Donate Me Any Amount From 10 Rs Upto Your Choice."""
    HELP_TXT = """<b>Hey</b> {}

Here Is The Help For My Commands."""


# Validate only after the module is fully defined.
Config.validate()
