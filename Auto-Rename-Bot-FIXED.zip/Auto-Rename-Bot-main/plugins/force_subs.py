from pyrogram import Client, filters, enums
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram.errors import UserNotParticipant, ChatAdminRequired, PeerIdInvalid, UsernameNotOccupied, ChannelInvalid
from config import Config
from helper.database import madflixbotz


def _channel_url(channel):
    if not channel:
        return None
    value = str(channel).strip()
    if value.startswith("https://t.me/"):
        return value
    if value.startswith("@"):
        return f"https://t.me/{value[1:]}"
    if value.lstrip("-").isdigit():
        return None
    return f"https://t.me/{value}"


async def not_subscribed(_, client, message):
    if not Config.FORCE_SUB:
        return False
    try:
        user = await client.get_chat_member(Config.FORCE_SUB, message.from_user.id)
        return user.status == enums.ChatMemberStatus.BANNED
    except UserNotParticipant:
        return True
    except (ChatAdminRequired, PeerIdInvalid, UsernameNotOccupied, ChannelInvalid) as e:
        # A force-sub configuration/permission problem must not make the bot unusable.
        print(f"Force-sub check unavailable: {e}")
        return False
    except Exception as e:
        print(f"Force-sub check error: {e}")
        return False


@Client.on_message(filters.private & filters.create(not_subscribed))
async def forces_sub(client, message):
    buttons = []
    url = _channel_url(Config.FORCE_SUB)
    if url:
        buttons = [[InlineKeyboardButton(text="🔺 Join Update Channel 🔺", url=url)]]
    text = "<b>Hello Dear!\n\nYou Need To Join My Channel To Use Me.\n\nKindly Join The Channel.</b>"
    try:
        user = await client.get_chat_member(Config.FORCE_SUB, message.from_user.id)
        if user.status == enums.ChatMemberStatus.BANNED:
            return await message.reply_text("Sorry, You Are Banned From Using Me.")
        return
    except UserNotParticipant:
        return await message.reply_text(text=text, reply_markup=InlineKeyboardMarkup(buttons) if buttons else None)
    except (ChatAdminRequired, PeerIdInvalid, UsernameNotOccupied, ChannelInvalid) as e:
        print(f"Force-sub reply check unavailable: {e}")
        return
