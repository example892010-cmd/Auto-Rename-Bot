from datetime import datetime
import os
import re
import time
from hachoir.metadata import extractMetadata
from hachoir.parser import createParser
from PIL import Image
from pyrogram import Client, filters
from helper.utils import progress_for_pyrogram, humanbytes, convert
from helper.database import madflixbotz

renaming_operations = {}

pattern1 = re.compile(r'S(\d+)(?:E|EP)(\d+)', re.I)
pattern2 = re.compile(r'S(\d+)\s*(?:E|EP|-\s*EP)(\d+)', re.I)
pattern3 = re.compile(r'(?:[([<{]?\s*(?:E|EP)\s*(\d+)\s*[)\]>}]?)', re.I)
pattern4 = re.compile(r'S(\d+)[^\d]*(\d+)', re.I)
patternX = re.compile(r'(\d+)')

def extract_quality(filename):
    patterns = [
        (re.compile(r'\b(\d{3,4}p)\b', re.I), None),
        (re.compile(r'[([<{]?\s*4k\s*[)\]>}]?', re.I), '4k'),
        (re.compile(r'[([<{]?\s*2k\s*[)\]>}]?', re.I), '2k'),
        (re.compile(r'\bHdRip\b', re.I), 'HdRip'),
        (re.compile(r'[([<{]?\s*4kx?264\s*[)\]>}]?', re.I), '4kX264'),
        (re.compile(r'[([<{]?\s*4kx265\s*[)\]>}]?', re.I), '4kx265'),
    ]
    for pattern, value in patterns:
        match = pattern.search(filename)
        if match:
            return match.group(1) if value is None else value
    return "Unknown"

def extract_episode_number(filename):
    for pattern in (pattern1, pattern2, pattern3, pattern4):
        match = pattern.search(filename)
        if match:
            return match.group(2) if len(match.groups()) > 1 else match.group(1)
    match = patternX.search(filename)
    return match.group(1) if match else None

def _replace_placeholders(template, episode, quality):
    for placeholder in ("episode", "Episode", "EPISODE", "{episode}"):
        template = template.replace(placeholder, str(episode), 1)
    for placeholder in ("quality", "Quality", "QUALITY", "{quality}"):
        template = template.replace(placeholder, quality, 1)
    return template

@Client.on_message(filters.private & (filters.document | filters.video | filters.audio))
async def auto_rename_files(client, message):
    user_id = message.from_user.id
    format_template = await madflixbotz.get_format_template(user_id)
    media_preference = await madflixbotz.get_media_preference(user_id)
    if not format_template:
        return await message.reply_text("Please Set An Auto Rename Format First Using /autorename")

    if message.document:
        file_id = message.document.file_id
        file_name = message.document.file_name or "file"
        original_size = message.document.file_size
        default_type = "document"
    elif message.video:
        file_id = message.video.file_id
        file_name = message.video.file_name or "video.mp4"
        original_size = message.video.file_size
        default_type = "video"
    elif message.audio:
        file_id = message.audio.file_id
        file_name = message.audio.file_name or "audio.mp3"
        original_size = message.audio.file_size
        default_type = "audio"
    else:
        return

    media_type = media_preference if media_preference in {"document", "video", "audio"} else default_type
    if file_id in renaming_operations and (datetime.now() - renaming_operations[file_id]).total_seconds() < 10:
        return
    renaming_operations[file_id] = datetime.now()

    file_path = None
    ph_path = None
    download_msg = None
    try:
        episode_number = extract_episode_number(file_name)
        if not episode_number:
            return await message.reply_text("I couldn't detect the episode number from this filename.")
        quality = extract_quality(file_name)
        if quality == "Unknown" and any(x in format_template for x in ("quality", "Quality", "QUALITY", "{quality}")):
            quality = "Unknown"
        new_name = _replace_placeholders(format_template, episode_number, quality)
        extension = os.path.splitext(file_name)[1] or (".mp4" if media_type == "video" else ".mp3" if media_type == "audio" else ".mkv")
        new_file_name = f"{new_name}{extension}"
        os.makedirs("downloads", exist_ok=True)
        file_path = os.path.join("downloads", new_file_name)

        download_msg = await message.reply_text("Trying To Download.....")
        await client.download_media(message, file_name=file_path, progress=progress_for_pyrogram, progress_args=("Download Started....", download_msg, time.time()))

        duration = 0
        try:
            metadata = extractMetadata(createParser(file_path))
            if metadata and metadata.has("duration"):
                duration = metadata.get('duration').seconds
        except Exception as e:
            print(f"Duration extraction failed: {e}")

        await download_msg.edit("Trying To Upload.....")
        c_caption = await madflixbotz.get_caption(user_id)
        c_thumb = await madflixbotz.get_thumbnail(user_id)
        caption = c_caption.format(filename=new_file_name, filesize=humanbytes(original_size), duration=convert(duration)) if c_caption else f"**{new_file_name}**"

        if c_thumb:
            ph_path = await client.download_media(c_thumb)
        elif media_type == "video" and message.video.thumbs:
            ph_path = await client.download_media(message.video.thumbs[0].file_id)
        if ph_path:
            try:
                with Image.open(ph_path) as img:
                    img.convert("RGB").resize((320, 320)).save(ph_path, "JPEG")
            except Exception as e:
                print(f"Thumbnail processing failed: {e}")
                ph_path = None

        kwargs = dict(caption=caption, thumb=ph_path, progress=progress_for_pyrogram, progress_args=("Upload Started.....", download_msg, time.time()))
        if media_type == "document":
            await client.send_document(message.chat.id, document=file_path, **kwargs)
        elif media_type == "video":
            await client.send_video(message.chat.id, video=file_path, duration=duration, **kwargs)
        else:
            await client.send_audio(message.chat.id, audio=file_path, duration=duration, **kwargs)
        await download_msg.delete()
    except Exception as e:
        print(f"Rename error: {e}")
        if download_msg:
            try:
                await download_msg.edit(f"Error: {e}")
            except Exception:
                pass
    finally:
        renaming_operations.pop(file_id, None)
        for path in (file_path, ph_path):
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
