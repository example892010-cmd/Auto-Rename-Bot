from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from helper.database import madflixbotz
from config import Config, Txt


def main_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('📢 Updates', url='https://t.me/+1CcAFHLS2tU4YWVl'), InlineKeyboardButton('💬 Support', url='https://t.me/+1jDuhUQ41hA1YmVl')],
        [InlineKeyboardButton('⚙️ Help', callback_data='help'), InlineKeyboardButton('💙 About', callback_data='about')],
        [InlineKeyboardButton('🧑‍💻 Developer', url='https://t.me/TANJIROKAMADO404')]
    ])


async def send_start(client, message, user):
    caption = Txt.START_TXT.format(user.mention)
    if Config.START_PIC and not Config.START_PIC.startswith(("https://t.me/", "http://t.me/", "https://telegram.me/", "http://telegram.me/")):
        try:
            await message.reply_photo(Config.START_PIC, caption=caption, reply_markup=main_buttons())
            return
        except Exception as e:
            print(f"START_PIC failed, falling back to text: {e}")
    await message.reply_text(caption, reply_markup=main_buttons(), disable_web_page_preview=True)


@Client.on_message(filters.private & filters.command("start"))
async def start(client, message):
    await madflixbotz.add_user(client, message)
    await send_start(client, message, message.from_user)


@Client.on_callback_query()
async def cb_handler(client, query: CallbackQuery):
    try:
        data = query.data
        user_id = query.from_user.id
        if data == "home":
            await query.message.edit_text(Txt.START_TXT.format(query.from_user.mention), disable_web_page_preview=True, reply_markup=main_buttons())
        elif data == "caption":
            await query.message.edit_text(Txt.CAPTION_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
        elif data == "help":
            await query.message.edit_text(Txt.HELP_TXT.format(client.mention), disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⚙️ Setup AutoRename Format ⚙️", callback_data='file_names')],[InlineKeyboardButton('🖼️ Thumbnail', callback_data='thumbnail'), InlineKeyboardButton('✏️ Caption', callback_data='caption')],[InlineKeyboardButton('🏠 Home', callback_data='home'), InlineKeyboardButton('💰 Donate', callback_data='donate')]]))
        elif data == "donate":
            await query.message.edit_text(Txt.DONATE_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
        elif data == "file_names":
            format_template = await madflixbotz.get_format_template(user_id) or "Not Set"
            await query.message.edit_text(Txt.FILE_NAME_TXT.format(format_template=format_template), disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
        elif data == "thumbnail":
            markup = InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]])
            if query.message.photo:
                await query.message.edit_caption(caption=Txt.THUMBNAIL_TXT, reply_markup=markup)
            else:
                await query.message.edit_text(Txt.THUMBNAIL_TXT, reply_markup=markup)
        elif data == "about":
            await query.message.edit_text(Txt.ABOUT_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="home")]]))
        elif data == "close":
            try:
                await query.message.delete()
            except Exception:
                pass
        await query.answer()
    except Exception as e:
        print(f"Callback handler error: {e}")
        try:
            await query.answer("Something went wrong. Please try again.", show_alert=True)
        except Exception:
            pass
