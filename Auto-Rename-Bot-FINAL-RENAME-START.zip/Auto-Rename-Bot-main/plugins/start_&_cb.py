from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from helper.database import madflixbotz
from config import Config, Txt

UPDATES_URL = "https://t.me/+1CcAFHLS2tU4YWVl"
SUPPORT_URL = "https://t.me/+1jDuhUQ41hA1YmVl"
DEVELOPER_URL = "https://t.me/TANJIROKAMADO404"
START_POST_CHAT = "Animetamildubbedseries"
START_POST_ID = 12512

def start_buttons():
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("📢 Updates", url=UPDATES_URL),
        InlineKeyboardButton("💬 Support", url=SUPPORT_URL)
    ],[
        InlineKeyboardButton("⚙️ Help", callback_data="help"),
        InlineKeyboardButton("💙 About", callback_data="about")
    ],[
        InlineKeyboardButton("🧑‍💻 Developer", url=DEVELOPER_URL)
    ]])

def start_text(user):
    return Txt.START_TXT.format(first_name=user.first_name or "there", mention=user.mention)

@Client.on_message(filters.private & filters.command("start"))
async def start(client, message):
    user = message.from_user
    await madflixbotz.add_user(client, message)
    button = start_buttons()
    try:
        post = await client.get_messages(START_POST_CHAT, START_POST_ID)
        if post and post.photo:
            await message.reply_photo(post.photo.file_id, caption=start_text(user), reply_markup=button)
            return
    except Exception as e:
        print(f"START_PIC post error: {e}")
    await message.reply_text(start_text(user), reply_markup=button, disable_web_page_preview=True)

@Client.on_callback_query()
async def cb_handler(client, query: CallbackQuery):
    data = query.data
    user = query.from_user
    user_id = user.id
    if data == "home":
        await query.message.edit_text(start_text(user), disable_web_page_preview=True, reply_markup=start_buttons())
    elif data == "caption":
        await query.message.edit_text(Txt.CAPTION_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
    elif data == "help":
        await query.message.edit_text(Txt.HELP_TXT.format(client.mention), disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⚙️ Setup AutoRename Format", callback_data="file_names")],[InlineKeyboardButton("🖼️ Thumbnail", callback_data="thumbnail"), InlineKeyboardButton("✏️ Caption", callback_data="caption")],[InlineKeyboardButton("🏠 Home", callback_data="home")]]))
    elif data == "file_names":
        format_template = await madflixbotz.get_format_template(user_id)
        await query.message.edit_text(Txt.FILE_NAME_TXT.format(format_template=format_template or "Not Set"), disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
    elif data == "thumbnail":
        await query.message.edit_text(Txt.THUMBNAIL_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="help")]]))
    elif data == "about":
        await query.message.edit_text(Txt.ABOUT_TXT, disable_web_page_preview=True, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ Close", callback_data="close"), InlineKeyboardButton("🔙 Back", callback_data="home")]]))
    elif data == "close":
        try:
            await query.message.delete()
        except Exception:
            pass

