<img src="https://graph.org/file/4b306f4b15c23a8f22e58.jpg" alt="logo" target="/blank">

<h1 align="center">
 <b><a href="https://t.me/autorenamexbot" target="/blank"> Auto Rename Bot </a></>
</h1>

<p align="center">🩵 Thanks for Being Here 🩵</p>


### CONFIGS VARIABLES

* `BOT_TOKEN` - Get bot token from @BotFather
* `API_ID` - From my.telegram.org
* `API_HASH` - From my.telegram.org
* `ADMIN` - Admin user id
* `LOG_CHANNEL` - Bot Log Channel Id startswith -100 must.
* `DB_URL` - Mongo Database URL from https://cloud.mongodb.com
* `DB_NAME` - Your database name from mongoDB. (Optional)
* `FORCE_SUB` - Your force sub channel username without @ (Optional)
* `START_PIC` - Start message photo. (Optional)



### DEPLOYEMENT SUPPORT

<summary>Deploy To Koyeb</summary>
<p>
<br>                 
<a target="/blank" href="https://app.koyeb.com/deploy?type=git&repository=github.com/TANJIROKAMADO404/Auto-Rename-Bot&branch=main&name=auto-rename-bot" >
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy">
</a>
</p>

<summary>Deploy To Heroku</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/TANJIROKAMADO404/Auto-Rename-Bot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>





### FEATURES
 - Renames very fast .
 - Permanent Thumbnail support.
 - Supports Broadcasts.
 - Set custom caption.
 - Has a custom Start-up pic.
 - Force subscribe available.
 - Supports ulimited renaming at a time.
 - Deploy to Koyeb + Heroku + Railway.
 - Automatically rename your files
 - Set mediatype to upload filetype
 - Developer Service 24x7. 🔥



### ALL COMMANDS

```
start - Check if the bot is running.
autorename - To auto rename your files.
setmedia - To set your media type preference.
tutorial - To know how to use me.
viewthumb - To view current thumbnail.
delthumb - To delete current thumbnail.
set_caption - set a custom caption.
see_caption - see your custom caption.
del_caption - delete custom caption.
restart - To restart the bot [FOR ADMINS USE ONLY]
broadcast - Message Broadcast command [FOR ADMINS USE ONLY].
status - Check bot status [FOR ADMINS USE ONLY].
```



### ❤️ RESPECTING ❤️
- [TANJIROKAMADO404](https://github.com/TANJIROKAMADO404)
- [Trippy](https://github.com/Trippy07) 
- [lntechnical](https://github.com/lntechnical2)

### 😍 BOTS CHANNEL 😍
- [ANIFLIXANIMETAMIL](https://t.me/ANIFLIXANIMETAMIL)
- [ANIFLIXANIMETAMIL](https://t.me/ANIFLIXANIMETAMIL)

### 💕 CONTACT DEVELOPER 💕
- [@TANJIROKAMADO404](https://t.me/TANJIROKAMADO404)
- [Trippy](https://t.me/Trippy_xt)

### ☕ BUY ME A COFFEE ☕
- [PayPal](https://paypal.me/jishudeveloper/2.50USD)
- [PhonePe](https://graph.org/file/6822df5af3a2e80637172.jpg)
- [UPI](https://graph.org/file/b831109be4acff5c966d2.jpg)
